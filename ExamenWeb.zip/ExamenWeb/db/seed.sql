INSERT INTO usuarios (username, password_hash, rol)
VALUES ('JEAN', '$2a$12$NqLzO3z/fD5y.QkOqGg9x.u.Z2qZ61e/2F9/13.7.6.6.1/4.2.1', 'ADMIN');