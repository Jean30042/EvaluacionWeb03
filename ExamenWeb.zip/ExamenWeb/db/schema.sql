CREATE TABLE usuarios (
                          id BIGSERIAL PRIMARY KEY,
                          username VARCHAR(50) NOT NULL UNIQUE,
                          password_hash VARCHAR(255) NOT NULL,
                          rol VARCHAR(20) NOT NULL DEFAULT 'ADMIN'
);

CREATE TABLE materias (
                          id BIGSERIAL PRIMARY KEY,
                          codigo CHAR(6) NOT NULL UNIQUE,
                          nombre VARCHAR(80) NOT NULL,
                          creditos SMALLINT NOT NULL CHECK (creditos BETWEEN 1 AND 6),
                          semestre SMALLINT NOT NULL CHECK (semestre BETWEEN 1 AND 10),
                          activa BOOLEAN NOT NULL DEFAULT TRUE
);