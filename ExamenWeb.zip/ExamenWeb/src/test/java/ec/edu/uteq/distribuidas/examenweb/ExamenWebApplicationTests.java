package ec.edu.uteq.distribuidas.examenweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExamenWebApplicationTests {

    @Test
    void contextLoads() {
    }

}
