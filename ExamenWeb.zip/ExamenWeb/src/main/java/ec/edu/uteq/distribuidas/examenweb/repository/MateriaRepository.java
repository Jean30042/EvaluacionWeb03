package ec.edu.uteq.distribuidas.examenweb.repository;

import ec.edu.uteq.distribuidas.examenweb.model.Materia;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface MateriaRepository extends JpaRepository<Materia, Long> {
    List<Materia> findByActivaTrue();
}