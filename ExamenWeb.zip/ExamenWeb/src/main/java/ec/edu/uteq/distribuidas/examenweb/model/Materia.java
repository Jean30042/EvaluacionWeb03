package ec.edu.uteq.distribuidas.examenweb.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;

@Entity
@Table(name = "materias")
public class Materia {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false, length = 6)
    @NotBlank
    @Size(min = 6, max = 6)
    private String codigo;

    @Column(nullable = false, length = 80)
    @NotBlank
    private String nombre;

    @Column(nullable = false)
    @Min(1)
    @Max(6)
    private Integer creditos;

    @Column(nullable = false)
    @Min(1)
    @Max(10)
    private Integer semestre;

    @Column(nullable = false)
    private Boolean activa = true;

    // Recuerda generar los Getters y Setters aquí (Alt + Insert)
}